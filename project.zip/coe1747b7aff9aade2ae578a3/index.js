document.getElementById("count").innerText = 5


